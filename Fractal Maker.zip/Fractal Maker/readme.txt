PLEASE WATCH THE BELOW TUTORIAL BEFORE USING THE SOFTWARE:
https://www.youtube.com/watch?v=fdCYgWEqKjk

PRESS B to switch between design and build mode
PRESS ESCAPE to switch load mode on and off

In design mode:
LEFT CLICK screen to place points, and PRESS SPACEBAR to delete points
Use NUMBER KEYS to change number of sides of your fractal
press B to switch into build mode

In Build mode:
use WASD keys and I O keys to navigate fractal.
PRESS Q to take a shot of the current fractal to set as a wallpaper.
PRESS F key to toggle freezing your fractal.

In load mode:
Use UP and DOWN keys to navigate your files
to save your file, PRESS RETURN
to give a new filename, use BACKSPACE and ALPHA keys to type a new name

In wallpapers folder, load your ps file in this website to convert it.
http://psviewer.org/convertpstojpg.aspx
